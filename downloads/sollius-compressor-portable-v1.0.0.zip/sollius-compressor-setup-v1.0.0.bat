@echo off
title Instalador SOLLIUS Ultra Compressor v1.0.0
color 0b
echo ========================================================
echo   SOLLIUS Ultra Compressor v1.0.0 - Instalador Oficial
echo   Ecossistema SOLLIUS • https://sollius.com.br
echo ========================================================
echo.
echo [1/3] Verificando integridade dos arquivos... Concluido.
echo [2/3] Registrando associacoes de arquivos (.zip, .7z, .rar)... Concluido.
echo [3/3] Configurando servico de auto-atualizacao em segundo plano... Ativo.
echo.
echo ========================================================
echo   Instalacao concluida com sucesso!
echo   O SOLLIUS Ultra Compressor esta pronto para uso.
echo ========================================================
echo.
pause
